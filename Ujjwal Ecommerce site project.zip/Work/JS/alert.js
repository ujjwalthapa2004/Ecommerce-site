function popUp(){
    alert("Your item has been purchased,Thank You!");
}
